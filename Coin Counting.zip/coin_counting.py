import cv2
import numpy as np
import argparse

parser = argparse.ArgumentParser(description="Coin Counter")
parser.add_argument("-i", "--image", required=True, help="Path to the coin image")
opts = vars(parser.parse_args())

image = cv2.imread(opts["image"])
if image is None:
    raise FileNotFoundError("Image not found. Check the path.")

resized = cv2.resize(image, (600, 600))
gray = cv2.cvtColor(resized, cv2.COLOR_BGR2GRAY)

blurred = cv2.GaussianBlur(gray, (11, 11), 0)
edged = cv2.Canny(blurred, 20, 100)

kernel = np.ones((5,5), np.uint8)
closed = cv2.morphologyEx(edged, cv2.MORPH_CLOSE, kernel, iterations=2)

contours_info = cv2.findContours(closed.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
contours = contours_info[0] if len(contours_info) == 2 else contours_info[1]

filtered = [c for c in contours if 100 < cv2.contourArea(c) < 15000]

print(f"Detected coins: {len(filtered)}")

output = resized.copy()
cv2.drawContours(output, filtered, -1, (0, 255, 0), 2)

cv2.imshow("Original", resized)
cv2.imshow("Edges", edged)
cv2.imshow("Coins Detected", output)
cv2.waitKey(0)
cv2.destroyAllWindows()
