# USAGE
# python eyetracking.py --face cascades/haarcascade_frontalface_default.xml --eye cascades/haarcascade_eye.xml
# python eyetracking.py --face cascades/haarcascade_frontalface_default.xml --eye cascades/haarcascade_eye.xml --video video/eyes.mov

import cv2
import imutils
import argparse

# argument parser
ap = argparse.ArgumentParser()
ap.add_argument("-f", "--face", required=True, help="path to face cascade xml file")
ap.add_argument("-e", "--eye", required=True, help="path to eye cascade xml file")
ap.add_argument("-v", "--video", help="path to (optional) video file")
args = vars(ap.parse_args())

# load Haar cascades
face_cascade = cv2.CascadeClassifier(args["face"])
eye_cascade = cv2.CascadeClassifier(args["eye"])

# choose source
if not args.get("video", False):
    cap = cv2.VideoCapture(0)
else:
    cap = cv2.VideoCapture(args["video"])

while True:
    ret, frame = cap.read()
    if not ret:
        break

    frame = imutils.resize(frame, width=700)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # detect faces
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(80, 80))

    for (x, y, w, h) in faces:
        # draw face rectangle
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

        roi_gray = gray[y:y + h, x:x + w]
        roi_color = frame[y:y + h, x:x + w]

        # detect eyes inside face ROI
        eyes = eye_cascade.detectMultiScale(
            roi_gray,
            scaleFactor=1.1,
            minNeighbors=12,   # more strict → fewer false positives
            minSize=(25, 25),
            flags=cv2.CASCADE_SCALE_IMAGE
        )

        eye_count = 0
        for (ex, ey, ew, eh) in eyes:
            # filter eyes to be in upper half of the face
            if ey + eh < h * 0.6:  
                cv2.rectangle(roi_color, (ex, ey), (ex + ew, ey + eh), (255, 0, 0), 2)
                eye_count += 1

        # if only 1 eye detected, relax filter a bit
        if eye_count < 2:
            eyes = eye_cascade.detectMultiScale(roi_gray, scaleFactor=1.1, minNeighbors=8, minSize=(20, 20))
            for (ex, ey, ew, eh) in eyes:
                if ey + eh < h * 0.7:
                    cv2.rectangle(roi_color, (ex, ey), (ex + ew, ey + eh), (0, 255, 255), 2)

    # show result
    cv2.imshow("Tracking", frame)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
