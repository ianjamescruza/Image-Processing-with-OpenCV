# USAGE
# python track.py
# python track.py --video video/iphonecase.mov
# python track.py --color red

import cv2
import numpy as np
import argparse
import time
from functools import reduce 

COLOR_BOUNDS = {
    "blue":  [(np.array([100, 150, 50]), np.array([140, 255, 255]))],
    "green": [(np.array([40, 70, 70]), np.array([80, 255, 255]))],
    "red": [
        (np.array([0, 120, 70]), np.array([10, 255, 255])),  
        (np.array([170, 120, 70]), np.array([180, 255, 255])) 
    ]
}

DRAW_COLOR = {
    "blue":  (255, 0, 0),
    "green": (0, 255, 0),
    "red":   (0, 0, 255)
}

def build_mask(hsv_frame, color_name):
    """Return binary mask for the selected color."""
    masks = [cv2.inRange(hsv_frame, low, high) for (low, high) in COLOR_BOUNDS[color_name]]
    if len(masks) == 1:
        return masks[0]
    return reduce(cv2.bitwise_or, masks)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-v", "--video", help="path to video file (default: webcam)")
    parser.add_argument("-c", "--color", default="blue",
                        help="color to track: blue, green, red (default=blue)")
    args = vars(parser.parse_args())

    source = args["video"] if args["video"] else 0
    cap = cv2.VideoCapture(source)

    if not cap.isOpened():
        print(f"⚠️ Cannot open video source: {source}")
        exit(1)

    color_name = args["color"].lower()
    if color_name not in COLOR_BOUNDS:
        print("Invalid color. Use: blue, green, or red.")
        exit(1)

    while True:
        ret, frame = cap.read()
        if not ret:
            print("End of stream or cannot grab frame.")
            break

        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        mask = build_mask(hsv, color_name)
        mask = cv2.GaussianBlur(mask, (3, 3), 0)

        cnts, _ = cv2.findContours(mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        if cnts:
            largest = max(cnts, key=cv2.contourArea)
            rect = np.int32(cv2.boxPoints(cv2.minAreaRect(largest)))
            cv2.drawContours(frame, [rect], -1, DRAW_COLOR[color_name], 2)

            cv2.putText(frame, f"Tracking {color_name.upper()}",
                        (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, DRAW_COLOR[color_name], 2)
        else:
            cv2.putText(frame, f"No {color_name.upper()} object detected",
                        (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (200, 200, 200), 2)

        cv2.imshow("Tracking", frame)
        cv2.imshow("Mask", mask)

        time.sleep(0.02)
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()
